const { Client, GatewayIntentBits, Collection, PermissionsBitField } = require('discord.js');
const fs = require('fs');
const db = require('croxydb');
const config = require('./ayarlar.json');

// --- İNTENTLER (Bütün korumalar için gerekli tüm izinler) ---
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildModeration,
        GatewayIntentBits.GuildWebhooks,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildIntegrations // Entegrasyon koruması için
    ]
});

// Ayarları ve komutları client içine entegre ediyoruz
client.config = config;
client.commands = new Collection();
// Embed log aracını client'a bağlıyoruz
client.sendLog = require('./src/utils/embed.js');

// --- KATEGORİ BAZLI WHITELIST KONTROL FONKSİYONU ---
client.checkWhitelist = async (member, guildOwnerId, action = null) => {
    if (!member) return false;

    const guardConfig = client.config.guardSettings;
    
    // 1. FULL YETKİLİ KONTROLÜ (Sunucu Sahibi, Botun kendisi, ayarlar.json'daki Kişiler ve Güvenli Roller)
    if (member.id === guildOwnerId || member.id === client.user.id || guardConfig.safeUsers.includes(member.id)) return true;
    if (member.user && member.user.bot && guardConfig.safeBots.includes(member.id)) return true;
    if (member.roles && member.roles.cache.some(role => guardConfig.safeRoles.includes(role.id))) return true;

    // 2. KATEGORİ BAZLI (ÖZEL .wl) YETKİ KONTROLÜ
    // Eğer fonksiyona bir 'action' (olay adı) gönderilmişse, veritabanına bakarak kişinin o işleme özel izni var mı kontrol et.
    if (action) {
        const userWl = db.get(`wl_${member.id}`) || [];
        
        // Event isimlerinin hangi '.wl' kategorisine ait olduğunu eşleştiriyoruz
        const actionMap = {
            'emojiCreate': 'emoji', 'emojiDelete': 'emoji',
            'stickerCreate': 'emoji', 'stickerDelete': 'emoji',
            'channelCreate': 'kanal', 'channelDelete': 'kanal', 'channelUpdate': 'kanal',
            'roleCreate': 'rol', 'roleDelete': 'rol', 'roleUpdate': 'rol',
            'guildBanAdd': 'ban', 'guildMemberRemove': 'kick',
            'guildMemberAdd': 'bot', 'guildUpdate': 'sunucu', 'webhookUpdate': 'sunucu',
            'integrationCreate': 'sunucu',
            'voiceStateUpdate': 'kick'
        };

        const requiredCategory = actionMap[action];
        
        // Eğer bu işlem bir kategoriye denk geliyorsa ve o kullanıcıda bu yetki varsa güvenli say (true)
        if (requiredCategory && userWl.includes(requiredCategory)) return true;
    }

    return false; // Yukarıdaki hiçbir şarta uymuyorsa GÜVENLİ DEĞİLDİR.
};

// --- YETKİLERİ KAPATMA FONKSİYONU (SUNUCU KİLİT) ---
client.closeAllAdminPermissions = async (guild) => {
    const safeRoles = client.config.guardSettings.safeRoles;

    guild.roles.cache.forEach(async (role) => {
        // Güvenli listede değilse VE Yönetici iznine sahipse
        if (!safeRoles.includes(role.id) && role.permissions.has(PermissionsBitField.Flags.Administrator)) {
            
            // Botun bu role gücü yetmiyorsa veya bu bir entegrasyon/bot rolüyse SESSİZCE es geç.
            if (role.comparePositionTo(guild.members.me.roles.highest) >= 0 || role.managed) {
                return; 
            }

            try {
                const newPermissions = role.permissions.remove(PermissionsBitField.Flags.Administrator);
                await role.setPermissions(newPermissions, 'Guard: Tehlike algılandı, Yönetici izni kapatıldı (KİLİT).');
            } catch (err) {
                console.error(`Rol güncellenemedi (${role.name}):`, err);
            }
        }
    });
};

// --- EVENT HANDLER ---
const eventFiles = fs.readdirSync('./src/events').filter(file => file.endsWith('.js'));

for (const file of eventFiles) {
    const event = require(`./src/events/${file}`);
    if (event.once) {
        client.once(event.name, (...args) => event.execute(...args, client));
    } else {
        client.on(event.name, (...args) => event.execute(...args, client));
    }
}

// --- COMMAND HANDLER ---
const commandFiles = fs.readdirSync('./src/commands').filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
    const command = require(`./src/commands/${file}`);
    client.commands.set(command.name, command);
}

// Bota giriş yaptırıyoruz
client.login(client.config.token);