const { ChannelType } = require('discord.js');
const db = require('croxydb');

module.exports = {
    name: 'yedek-kur',
    description: 'Alınan yedeği sunucuya kurar.',
    async execute(message, args, client) {
        const { guild, author, channel } = message;

        // --- YETKİ KONTROLÜ (SADECE SAHİP) ---
        if (guild.ownerId !== author.id) {
            return message.reply('❌ GÜVENLİK REDDİ: Bu komutu **SADECE** Sunucu Sahibi kullanabilir!');
        }

        const backupData = db.get(`backup_${guild.id}`);
        if (!backupData) {
            return message.reply('❌ Bu sunucuya ait herhangi bir yedek bulunamadı!');
        }

        await message.reply('⚠️ **DİKKAT:** Bu işlem sunucudaki **TÜM** mevcut kanalları ve rolleri silecek, yerine yedekteki verileri kuracaktır.\nOnaylıyor musunuz? Sadece **evet** veya **hayır** yazın. (15 saniyeniz var)');

        // Onay Filtresi
        const filter = m => m.author.id === author.id && ['evet', 'hayır'].includes(m.content.toLowerCase());
        const collector = channel.createMessageCollector({ filter, time: 15000, max: 1 });

        collector.on('collect', async (m) => {
            if (m.content.toLowerCase() === 'hayır') {
                return message.channel.send('✅ İşlem iptal edildi.');
            }

            if (m.content.toLowerCase() === 'evet') {
                const baslangicMesaji = await message.channel.send('🔄 **Yedek Kurulumu Başlıyor...** (Sunucu kilitleniyor, lütfen bitene kadar işlem yapmayın)');

                try {
                    // --- 1. TEMİZLİK AŞAMASI ---
                    // Bütün kanalları sil (Botun yetkisi yettiği kadar)
                    guild.channels.cache.forEach(async (ch) => {
                        try { await ch.delete(); } catch (e) {}
                    });

                    // Bütün rolleri sil (Bot rollerini ve everyone'ı hariç tutuyoruz)
                    guild.roles.cache.forEach(async (rl) => {
                        if (!rl.managed && rl.id !== guild.id) {
                            try { await rl.delete(); } catch (e) {}
                        }
                    });

                    // --- 2. YENİDEN OLUŞTURMA AŞAMASI ---
                    // Rol ID'lerini eşlemek için bir Harita (Map) oluşturuyoruz. 
                    // (Çünkü yeni kurulan rolün ID'si farklı olacak, kanallara izin verirken eski ID'leri yenileriyle değiştirmeliyiz)
                    const roleMap = new Map();
                    roleMap.set(guild.id, guild.id); // everyone rolü eşleştirmesi

                    // Rolleri kur
                    for (const roleData of backupData.roles.reverse()) {
                        try {
                            const newRole = await guild.roles.create({
                                name: roleData.name,
                                color: roleData.color,
                                hoist: roleData.hoist,
                                permissions: BigInt(roleData.permissions),
                                mentionable: roleData.mentionable,
                                reason: 'Yedek Kurulumu: Rol'
                            });
                            roleMap.set(roleData.id, newRole.id); // Eski ID -> Yeni ID kaydet
                        } catch (e) { console.error("Rol kurulamadı:", e); }
                    }

                    // Kategorileri kur ve ID'lerini haritala
                    const categoryMap = new Map();
                    for (const catData of backupData.categories) {
                        try {
                            // İzinleri yeni ID'lere göre ayarla
                            const newOverwrites = catData.permissions.map(p => {
                                if (p.type === 0 && roleMap.has(p.id)) {
                                    return { id: roleMap.get(p.id), allow: BigInt(p.allow), deny: BigInt(p.deny), type: 0 };
                                }
                                return null;
                            }).filter(p => p !== null);

                            const newCat = await guild.channels.create({
                                name: catData.name,
                                type: ChannelType.GuildCategory,
                                permissionOverwrites: newOverwrites
                            });
                            categoryMap.set(catData.id, newCat.id);
                        } catch (e) { console.error("Kategori kurulamadı:", e); }
                    }

                    // Kanalları (Metin/Ses) kur
                    for (const chData of backupData.channels) {
                        try {
                            const newOverwrites = chData.permissions.map(p => {
                                if (p.type === 0 && roleMap.has(p.id)) {
                                    return { id: roleMap.get(p.id), allow: BigInt(p.allow), deny: BigInt(p.deny), type: 0 };
                                }
                                return null;
                            }).filter(p => p !== null);

                            await guild.channels.create({
                                name: chData.name,
                                type: chData.type,
                                topic: chData.topic,
                                nsfw: chData.nsfw,
                                bitrate: chData.type === ChannelType.GuildVoice ? chData.bitrate : undefined,
                                userLimit: chData.type === ChannelType.GuildVoice ? chData.userLimit : undefined,
                                rateLimitPerUser: chData.rateLimitPerUser,
                                parent: chData.parentId ? categoryMap.get(chData.parentId) : null, // Eski kategoriye at
                                permissionOverwrites: newOverwrites
                            });
                        } catch (e) { console.error("Kanal kurulamadı:", e); }
                    }

                    // Yeni açılan ilk metin kanalını bulup oraya mesaj at
                    setTimeout(async () => {
                        const newGenelChat = guild.channels.cache.find(c => c.type === ChannelType.GuildText);
                        if (newGenelChat) {
                            newGenelChat.send(`✅ <@${author.id}>, **Yedekleme işlemi başarıyla tamamlandı!** Tüm roller ve kanallar yerli yerine oturtuldu.`);
                        }
                    }, 5000);

                } catch (err) {
                    console.error(err);
                }
            }
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                message.reply('❌ 15 saniye içinde cevap vermediğiniz için yedek kurulum işlemi iptal edildi.');
            }
        });
    }
};