const db = require('croxydb');

module.exports = {
    name: 'wl',
    description: 'Kullanıcıya özel (kategori bazlı) whitelist yetkisi verir.',
    async execute(message, args, client) {
        const isOwner = message.guild.ownerId === message.author.id;
        const isFullSafe = client.config.guardSettings.safeUsers.includes(message.author.id);
        
        if (!isOwner && !isFullSafe) return message.reply('❌ Bu komutu sadece **Sunucu Sahibi** veya **Tam Yetkili** kişiler kullanabilir!');

        // ETİKET VEYA ID İLE KULLANICIYI BULMA (YENİ SİSTEM)
        let targetUser = message.mentions.users.first();
        if (!targetUser && args[0]) {
            try {
                targetUser = await client.users.fetch(args[0]);
            } catch (err) {
                return message.reply('❌ Belirtilen ID ile bir kullanıcı bulunamadı!');
            }
        }

        if (!targetUser) return message.reply('❌ Bir kullanıcı etiketlemelisin veya ID yazmalısın!\n**Kullanım:** `.wl @kullanıcı/ID <kategori>`');

        const category = args[1]?.toLowerCase();
        const validCategories = ['emoji', 'kanal', 'rol', 'ban', 'kick', 'bot', 'sunucu'];

        if (!category || !validCategories.includes(category)) {
            return message.reply(`❌ Geçerli bir kategori belirtmelisin!\n📋 **Kategoriler:** \`${validCategories.join(', ')}\``);
        }

        const dbKey = `wl_${targetUser.id}`;
        let userWl = db.get(dbKey) || [];

        if (userWl.includes(category)) {
            userWl = userWl.filter(c => c !== category);
            db.set(dbKey, userWl);
            return message.reply(`🔴 <@${targetUser.id}> adlı kullanıcının **${category.toUpperCase()}** yetkisi başarıyla **KALDIRILDI**!`);
        } else {
            userWl.push(category);
            db.set(dbKey, userWl);
            return message.reply(`🟢 <@${targetUser.id}> adlı kullanıcıya **${category.toUpperCase()}** yetkisi başarıyla **VERİLDİ**!`);
        }
    }
};