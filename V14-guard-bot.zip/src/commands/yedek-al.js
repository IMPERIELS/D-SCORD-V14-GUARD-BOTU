const { ChannelType } = require('discord.js');
const db = require('croxydb');

module.exports = {
    name: 'yedek-al',
    description: 'Sunucunun rol ve kanal yedeğini alır.',
    async execute(message, args, client) {
        const { guild, author, member } = message;

        // --- YETKİ KONTROLÜ ---
        const config = client.config.guardSettings;
        const isOwner = guild.ownerId === author.id;
        const isSafeUser = config.safeUsers.includes(author.id);
        const hasSafeRole = member.roles.cache.some(role => config.safeRoles.includes(role.id));

        if (!isOwner && !isSafeUser && !hasSafeRole) {
            return message.reply('❌ Bu komutu kullanmak için Güvenli (Whitelist) listesinde veya Sunucu Sahibi olmalısın!');
        }

        const uyariMesaji = await message.reply('⏳ Sunucu yedeği alınıyor, lütfen bekleyin (Bu işlem sunucu büyüklüğüne göre biraz sürebilir)...');

        try {
            // 1. Rolleri Yedekle (Everyone ve Bot rollerini hariç tutuyoruz)
            const roles = guild.roles.cache
                .filter(r => !r.managed && r.id !== guild.id)
                .sort((a, b) => b.position - a.position)
                .map(r => ({
                    id: r.id,
                    name: r.name,
                    color: r.color,
                    hoist: r.hoist,
                    permissions: r.permissions.bitfield.toString(),
                    mentionable: r.mentionable,
                    position: r.position
                }));

            // 2. Kategorileri Yedekle
            const categories = guild.channels.cache
                .filter(c => c.type === ChannelType.GuildCategory)
                .sort((a, b) => a.position - b.position)
                .map(c => ({
                    id: c.id,
                    name: c.name,
                    permissions: c.permissionOverwrites.cache.map(p => ({
                        id: p.id,
                        type: p.type,
                        allow: p.allow.bitfield.toString(),
                        deny: p.deny.bitfield.toString()
                    }))
                }));

            // 3. Kanalları (Metin/Ses) Yedekle
            const channels = guild.channels.cache
                .filter(c => c.type !== ChannelType.GuildCategory)
                .sort((a, b) => a.position - b.position)
                .map(c => ({
                    id: c.id,
                    name: c.name,
                    type: c.type,
                    parentId: c.parentId,
                    topic: c.topic,
                    nsfw: c.nsfw,
                    bitrate: c.bitrate,
                    userLimit: c.userLimit,
                    rateLimitPerUser: c.rateLimitPerUser,
                    permissions: c.permissionOverwrites.cache.map(p => ({
                        id: p.id,
                        type: p.type,
                        allow: p.allow.bitfield.toString(),
                        deny: p.deny.bitfield.toString()
                    }))
                }));

            // Veritabanına Kaydet
            const backupData = { roles, categories, channels, date: Date.now() };
            db.set(`backup_${guild.id}`, backupData);

            await uyariMesaji.edit(`✅ **Yedekleme Başarılı!**\nToplam **${roles.length}** rol, **${categories.length}** kategori ve **${channels.length}** kanal yedeklendi.\nKurulum için \`${client.config.prefix}yedek-kur\` yazabilirsiniz.`);
        } catch (error) {
            console.error(error);
            uyariMesaji.edit('❌ Yedek alınırken bir hata oluştu!');
        }
    }
};