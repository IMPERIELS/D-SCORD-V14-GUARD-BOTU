module.exports = {
    name: 'ping',
    description: 'Botun gecikme süresini ölçer.',
    execute(message, args, client) {
        const ping = client.ws.ping;
        message.reply(` Güncel gecikme sürem: **${ping}ms**`);
        
        // Örnek: Ayarlardan rol çekme kullanımı
        // const adminRolu = client.config.roller.adminRolId;
        // if (!message.member.roles.cache.has(adminRolu)) return message.reply("Yetkin yok!");
    },
};