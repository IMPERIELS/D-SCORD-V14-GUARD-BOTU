const { PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'panik',
    description: 'Saldırı anında üye rollerinin yazma/ses izinlerini kapatır.',
    async execute(message, args, client) {
        const { guild, author } = message;
        const config = client.config.guardSettings;

        // Sadece sunucu sahibi ve tam yetkililer kullanabilir
        if (guild.ownerId !== author.id && !config.safeUsers.includes(author.id)) {
            return message.reply('❌ Bu komutu sadece Tam Yetkililer kullanabilir!');
        }

        const islem = args[0]?.toLowerCase();
        if (!['aç', 'kapat'].includes(islem)) {
            return message.reply('**Kullanım:** `.panik aç` (Kilidi vurur) veya `.panik kapat` (İzinleri geri verir)');
        }

        // Ayarlardaki tüm kız ve erkek rollerini tek bir listede topluyoruz
        const uyeRolleri = [...(config.kizRolleri || []), ...(config.erkekRolleri || [])];
        if (uyeRolleri.length === 0) return message.reply('❌ Ayarlar dosyasında kız veya erkek rolü bulunamadı!');

        const msg = await message.reply(`⏳ Panik modu \`${islem.toUpperCase()}\` işlemi uygulanıyor, lütfen bekleyin...`);

        try {
            for (const rolId of uyeRolleri) {
                const rol = guild.roles.cache.get(rolId);
                if (rol) {
                    if (islem === 'aç') {
                        // Mesaj yazma ve ses kanallarına girme yetkilerini AL (Kırmızı yap)
                        await rol.setPermissions(rol.permissions.remove([PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.Connect]));
                    } else if (islem === 'kapat') {
                        // Mesaj yazma ve ses kanallarına girme yetkilerini GERİ VER (Yeşil yap)
                        await rol.setPermissions(rol.permissions.add([PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.Connect]));
                    }
                }
            }

            if (islem === 'aç') {
                await msg.edit('🚨 **PANİK MODU AKTİF!**\nTüm Kız ve Erkek rollerinin mesaj gönderme ve ses kanallarına bağlanma izinleri başarıyla KAPATILDI!');
            } else {
                await msg.edit('✅ **PANİK MODU DEVRE DIŞI!**\nTehlike geçti, Kız ve Erkek rollerinin izinleri eski haline getirildi.');
            }
        } catch (err) {
            console.error("Panik modu hatası:", err);
            msg.edit('❌ Roller güncellenirken botun yetkisi yetmemiş olabilir. Lütfen botun rolünü en üste taşıyın.');
        }
    }
};