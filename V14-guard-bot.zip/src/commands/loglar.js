const { ChannelType, PermissionsBitField } = require('discord.js');
const db = require('croxydb');

module.exports = {
    name: 'loglar',
    description: 'Tüm guard log kanallarını kategorisiyle birlikte otomatik kurar.',
    async execute(message, args, client) {
        const { guild, author } = message;

        // SADECE SUNUCU SAHİBİ
        if (guild.ownerId !== author.id) {
            return message.reply('❌ Bu komutu güvenliğiniz için **Sadece Sunucu Sahibi** kullanabilir!');
        }

        const msg = await message.reply('⏳ **Log kanalları kuruluyor...** Lütfen bekleyin.');

        try {
            // 1. Kategoriyi Kur (Everyone'a kapalı olacak şekilde)
            const category = await guild.channels.create({
                name: 'guard-log',
                type: ChannelType.GuildCategory,
                permissionOverwrites: [
                    {
                        id: guild.id, // @everyone rolünün ID'si sunucu ID'si ile aynıdır
                        deny: [PermissionsBitField.Flags.ViewChannel],
                    }
                ]
            });

            // 2. Açılacak kanalların listesi ve veritabanı karşılıkları
            const logNames = [
                { key: 'ban', name: 'ban-log' },
                { key: 'kick', name: 'kick-log' },
                { key: 'rol', name: 'rol-log' },
                { key: 'kanal', name: 'kanal-log' },
                { key: 'emoji', name: 'emoji-log' },
                { key: 'sunucu', name: 'sunucu-log' },
                { key: 'bot', name: 'bot-log' },
                { key: 'webhook', name: 'webhook-log' }
            ];

            const logData = {};

            // 3. Kanalları kategori içine sırayla aç
            for (const log of logNames) {
                const ch = await guild.channels.create({
                    name: log.name,
                    type: ChannelType.GuildText,
                    parent: category.id
                });
                
                // Kanal ID'sini key'e eşitle
                logData[log.key] = ch.id;
            }

            // 4. Veritabanına kaydet
            db.set(`logs_${guild.id}`, logData);

            await msg.edit('✅ **Tüm log kanalları başarıyla kuruldu ve Guard sistemine entegre edildi!**');

        } catch (error) {
            console.error("Loglar kurulurken hata:", error);
            msg.edit('❌ Kanallar kurulurken bir hata meydana geldi. Botun yetkilerini kontrol edin.');
        }
    }
};