const { AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'guildMemberAdd',
    async execute(member, client) {
        const { guild } = member;

        // --- 1. ANTI-BOT (İzinsiz Bot Ekleme Koruması) ---
        if (member.user.bot) {
            const fetchedLogs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.BotAdd });
            const log = fetchedLogs.entries.first();
            if (!log || log.createdTimestamp < (Date.now() - 5000)) return;

            if (log.target.id === member.id) {
                const executorMember = await guild.members.fetch(log.executor.id).catch(() => null);
                const isSafe = await client.checkWhitelist(executorMember, guild.ownerId, 'guildMemberAdd');

                if (!isSafe) {
                    try {
                        await client.closeAllAdminPermissions(guild);
                        await member.kick('Guard: İzinsiz bot.');
                        await client.sendLog(client, guild, 'bot', {
                            title: 'Sunucuya İzinsiz Bot Eklendi!',
                            description: `**Eklenen Bot:** <@${member.id}>\n\n🔒 **Aksiyon:** Sunucu kilitlendi, yönetici yetkileri çekildi.\n🔄 **Durum:** Yabancı bot sunucudan atıldı.`,
                            executor: log.executor
                        });
                    } catch (err) { console.error(err); }
                }
            }
            return; // Bot ise Anti-Raid kontrolüne gerek yok, buradan bitir.
        }

        // --- 2. ANTI-RAID (Fake / Yeni Hesap Koruması) ---
        const now = new Date().getTime();
        const creationDate = member.user.createdAt.getTime();
        const diff = now - creationDate;
        const days = Math.floor(diff / (1000 * 60 * 60 * 24)); // Milisaniyeyi güne çevirir

        // Eğer hesap 7 günden daha yeniyse:
        if (days < 7) {
            try {
                await member.kick('Guard: Anti-Raid (Yeni hesap tespiti).');
                
                await client.sendLog(client, guild, 'sunucu', {
                    title: 'Anti-Raid (Fake Hesap) Engellendi!',
                    description: `**Kullanıcı:** <@${member.id}>\n**Hesap Kuruluş:** Sadece **${days}** gün önce!\n\n🔒 **Aksiyon:** Hesap 7 günden daha yeni olduğu için olası raid/nuke saldırısına karşı **otomatik olarak sunucudan atıldı.**`,
                    color: 'Orange' // Diğer loglardan ayırmak için turuncu renk
                });
            } catch (e) { console.error('Anti-Raid Kick hatası:', e); }
        }
    },
};