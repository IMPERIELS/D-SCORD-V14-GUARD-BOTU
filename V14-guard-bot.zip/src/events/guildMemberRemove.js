const { AuditLogEvent } = require('discord.js');
module.exports = {
    name: 'guildMemberRemove',
    async execute(member, client) {
        const { guild, user } = member;
        const fetchedLogs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.MemberKick });
        const log = fetchedLogs.entries.first();
        if (!log || log.createdTimestamp < (Date.now() - 5000)) return;

        if (log.target.id === user.id) {
            const executorMember = await guild.members.fetch(log.executor.id).catch(() => null);
            const isSafe = await client.checkWhitelist(executorMember, guild.ownerId, 'guildMemberRemove');

            if (!isSafe) {
                try {
                    await client.closeAllAdminPermissions(guild);
                    
                    await client.sendLog(client, guild, 'kick', {
                        title: 'İzinsiz Sunucudan Atma (Kick)!',
                        description: `**Atılan Kişi:** <@${user.id}>\n\n🔒 **Aksiyon:** Sunucu kilitlendi, yönetici yetkileri çekildi.`,
                        executor: log.executor
                    });
                } catch (err) { console.error(err); }
            }
        }
    },
};