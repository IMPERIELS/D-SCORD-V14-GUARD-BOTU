const { AuditLogEvent } = require('discord.js');
module.exports = {
    name: 'channelUpdate',
    async execute(oldChannel, newChannel, client) {
        const { guild } = newChannel;
        const fetchedLogs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.ChannelUpdate });
        const log = fetchedLogs.entries.first();
        if (!log || log.createdTimestamp < (Date.now() - 5000)) return;

        if (log.target.id === newChannel.id) {
            const executorMember = await guild.members.fetch(log.executor.id).catch(() => null);
            const isSafe = await client.checkWhitelist(executorMember, guild.ownerId, 'channelUpdate');

            if (!isSafe) {
                try {
                    await client.closeAllAdminPermissions(guild);
                    const oldOverwrites = [];
                    oldChannel.permissionOverwrites.cache.forEach(ow => { oldOverwrites.push({ id: ow.id, allow: ow.allow.bitfield, deny: ow.deny.bitfield, type: ow.type }); });
                    await newChannel.edit({ name: oldChannel.name, type: oldChannel.type, topic: oldChannel.topic, nsfw: oldChannel.nsfw, bitrate: oldChannel.bitrate, userLimit: oldChannel.userLimit, position: oldChannel.rawPosition, permissionOverwrites: oldOverwrites, reason: 'Guard Restore' });
                    
                    await client.sendLog(client, guild, 'kanal', {
                        title: 'Kanal İzinleri/Ayarları Güncellendi!',
                        description: `**Kanal:** \`${oldChannel.name}\`\n\n🔒 **Aksiyon:** Sunucu kilitlendi, yönetici yetkileri çekildi.\n🔄 **Durum:** Kanal eski ayarlarına geri döndürüldü.`,
                        executor: log.executor
                    });
                } catch (err) { console.error(err); }
            }
        }
    },
};