module.exports = {
    name: 'messageCreate',
    async execute(message, client) {
        if (message.author.bot || !message.guild) return;

        const isSafe = (await client.checkWhitelist(message.member, message.guild.ownerId)) || message.member.permissions.has("Administrator");
        if (!isSafe) {
            const inviteRegex = /(discord\.gg\/|discordapp\.com\/invite\/|discord\.com\/invite\/)/i;
            const linkRegex = /(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/i;
            const spamRegex = /(@everyone|@here)/i;

            if (inviteRegex.test(message.content) || linkRegex.test(message.content)) {
                await message.delete().catch(() => {});
                return message.channel.send(`<@${message.author.id}>, bu sunucuda link/davet paylaşamazsın!`).then(msg => setTimeout(() => msg.delete(), 5000));
            }
            if (spamRegex.test(message.content)) {
                await message.delete().catch(() => {});
                return message.channel.send(`<@${message.author.id}>, izinsiz \`everyone\` veya \`here\` atamazsın!`).then(msg => setTimeout(() => msg.delete(), 5000));
            }
        }

        if (!message.content.startsWith(client.config.prefix)) return;
        const args = message.content.slice(client.config.prefix.length).trim().split(/ +/);
        const commandName = args.shift().toLowerCase();
        const command = client.commands.get(commandName);
        if (!command) return;

        try { command.execute(message, args, client); } 
        catch (error) { console.error(error); message.reply('❌ Komut çalıştırılamadı!'); }
    },
};