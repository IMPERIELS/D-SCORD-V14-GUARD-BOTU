const { AuditLogEvent } = require('discord.js');
module.exports = {
    name: 'integrationCreate',
    async execute(integration, client) {
        const { guild } = integration;
        const fetchedLogs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.IntegrationCreate });
        const log = fetchedLogs.entries.first();
        if (!log || log.createdTimestamp < (Date.now() - 5000)) return;

        const executorMember = await guild.members.fetch(log.executor.id).catch(() => null);
        const isSafe = await client.checkWhitelist(executorMember, guild.ownerId, 'integrationCreate');

        if (!isSafe) {
            try {
                await client.closeAllAdminPermissions(guild);
                await integration.delete('Guard Temizlik');
                
                await client.sendLog(client, guild, 'sunucu', {
                    title: 'İzinsiz Entegrasyon Kuruldu!',
                    description: `**Bağlantı:** \`${integration.name}\`\n\n🔒 **Aksiyon:** Sunucu kilitlendi.\n🔄 **Durum:** Entegrasyon bağlantısı anında koparıldı.`,
                    executor: log.executor
                });
            } catch (err) { console.error(err); }
        }
    },
};