const { AuditLogEvent } = require('discord.js');
module.exports = {
    name: 'emojiDelete',
    async execute(emoji, client) {
        const { guild } = emoji;
        const fetchedLogs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.EmojiDelete });
        const log = fetchedLogs.entries.first();
        if (!log || log.createdTimestamp < (Date.now() - 5000)) return;

        if (log.target.id === emoji.id) {
            const executorMember = await guild.members.fetch(log.executor.id).catch(() => null);
            const isSafe = await client.checkWhitelist(executorMember, guild.ownerId, 'emojiDelete');
            if (!isSafe) {
                try {
                    await client.closeAllAdminPermissions(guild);
                    await client.sendLog(client, guild, 'emoji', { title: 'İzinsiz Emoji Silindi!', description: `🔒 **Aksiyon:** Sunucu kilitlendi, yönetici yetkileri çekildi.`, executor: log.executor });
                } catch (err) { console.error(err); }
            }
        }
    },
};