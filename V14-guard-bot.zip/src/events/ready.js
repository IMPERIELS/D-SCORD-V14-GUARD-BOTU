const { ActivityType, ChannelType } = require('discord.js');
const cron = require('node-cron');
const db = require('croxydb');

module.exports = {
    name: 'ready',
    once: true,
    execute(client) {
        console.log(`${client.user.tag} olarak giriş yapıldı ve Guard aktif!`);
        
        // --- BOTUN OYNUYOR DURUMU ---
        const durumTipiMap = { 
            "Playing": ActivityType.Playing, 
            "Watching": ActivityType.Watching, 
            "Listening": ActivityType.Listening, 
            "Streaming": ActivityType.Streaming, 
            "Competing": ActivityType.Competing 
        };
        const secilenTip = durumTipiMap[client.config.botDurumTipi] || ActivityType.Playing;
        
        // --- BOTUN GÖRÜNÜM RENGİ (online, idle, dnd, invisible) ---
        // Eğer ayarlara yanlış bir şey yazılırsa bot çökmesin diye varsayılan olarak 'online' kalmasını da ekliyoruz.
        const secilenGozukme = client.config.botGozukme || 'online';

        // Durumu ve Rengi Ayarla
        client.user.setPresence({ 
            activities: [{ name: client.config.botDurum, type: secilenTip }], 
            status: secilenGozukme 
        });

        // --- OTOMATİK YEDEKLEME SİSTEMİ (Her Gece 04:00) ---
        cron.schedule('0 4 * * *', async () => {
            console.log('🔄 Cron-Job: Otomatik yedekleme işlemi başlatılıyor...');
            
            client.guilds.cache.forEach(async (guild) => {
                try {
                    // Rolleri Yedekle
                    const roles = guild.roles.cache.filter(r => !r.managed && r.id !== guild.id).sort((a, b) => b.position - a.position).map(r => ({
                        id: r.id, name: r.name, color: r.color, hoist: r.hoist, permissions: r.permissions.bitfield.toString(), mentionable: r.mentionable, position: r.position
                    }));

                    // Kategorileri Yedekle
                    const categories = guild.channels.cache.filter(c => c.type === ChannelType.GuildCategory).sort((a, b) => a.position - b.position).map(c => ({
                        id: c.id, name: c.name, permissions: c.permissionOverwrites.cache.map(p => ({ id: p.id, type: p.type, allow: p.allow.bitfield.toString(), deny: p.deny.bitfield.toString() }))
                    }));

                    // Kanalları Yedekle
                    const channels = guild.channels.cache.filter(c => c.type !== ChannelType.GuildCategory).sort((a, b) => a.position - b.position).map(c => ({
                        id: c.id, name: c.name, type: c.type, parentId: c.parentId, topic: c.topic, nsfw: c.nsfw, bitrate: c.bitrate, userLimit: c.userLimit, rateLimitPerUser: c.rateLimitPerUser,
                        permissions: c.permissionOverwrites.cache.map(p => ({ id: p.id, type: p.type, allow: p.allow.bitfield.toString(), deny: p.deny.bitfield.toString() }))
                    }));

                    db.set(`backup_${guild.id}`, { roles, categories, channels, date: Date.now() });
                    console.log(`✅ [${guild.name}] Otomatik günlük sunucu yedeği başarıyla alındı.`);
                } catch (err) {
                    console.error(`Oto yedek hatası (${guild.name}):`, err);
                }
            });
        }, {
            scheduled: true,
            timezone: "Europe/Istanbul"
        });
    },
};