const { AuditLogEvent, PermissionsBitField } = require('discord.js');
module.exports = {
    name: 'guildMemberUpdate',
    async execute(oldMember, newMember, client) {
        const { guild } = newMember;

        // 1. Anti-Timeout
        if (!oldMember.isCommunicationDisabled() && newMember.isCommunicationDisabled()) {
            const fetchedLogs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.MemberUpdate });
            const log = fetchedLogs.entries.first();
            if (log && log.createdTimestamp > (Date.now() - 5000) && log.target.id === newMember.id) {
                const executorMember = await guild.members.fetch(log.executor.id).catch(() => null);
                const isSafe = await client.checkWhitelist(executorMember, guild.ownerId, 'kick');
                if (!isSafe) {
                    try {
                        await client.closeAllAdminPermissions(guild);
                        await newMember.timeout(null, 'Guard Restore');
                        await client.sendLog(client, guild, 'kick', {
                            title: 'İzinsiz Susturma (Timeout)!',
                            description: `**Susturulan:** <@${newMember.id}>\n\n🔒 **Aksiyon:** Sunucu kilitlendi.\n🔄 **Durum:** Kullanıcının susturması açıldı.`,
                            executor: log.executor
                        });
                    } catch (err) { console.error(err); }
                }
            }
        }

        // 2. Sağ Tık Kritik Rol Verme
        const addedRoles = newMember.roles.cache.filter(role => !oldMember.roles.cache.has(role.id));
        if (addedRoles.size > 0) {
            const isDangerous = addedRoles.some(role => role.permissions.has(PermissionsBitField.Flags.Administrator) || role.permissions.has(PermissionsBitField.Flags.ManageRoles) || role.permissions.has(PermissionsBitField.Flags.ManageChannels) || role.permissions.has(PermissionsBitField.Flags.ManageGuild) || role.permissions.has(PermissionsBitField.Flags.BanMembers) || role.permissions.has(PermissionsBitField.Flags.KickMembers));
            if (isDangerous) {
                const fetchedLogs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.MemberRoleUpdate });
                const log = fetchedLogs.entries.first();
                if (log && log.createdTimestamp > (Date.now() - 5000) && log.target.id === newMember.id) {
                    const executorMember = await guild.members.fetch(log.executor.id).catch(() => null);
                    const isSafe = await client.checkWhitelist(executorMember, guild.ownerId, 'rol');
                    if (!isSafe) {
                        try {
                            await client.closeAllAdminPermissions(guild);
                            await newMember.roles.remove(addedRoles, 'Guard Restore');
                            await client.sendLog(client, guild, 'rol', {
                                title: 'Tehlikeli Yetki Dağıtımı!',
                                description: `**Yetki Verilen Kişi:** <@${newMember.id}>\n**Verilen Roller:** ${addedRoles.map(r => `\`${r.name}\``).join(', ')}\n\n🔒 **Aksiyon:** Sunucu kilitlendi.\n🔄 **Durum:** Roller üyeden geri alındı.`,
                                executor: log.executor
                            });
                        } catch (err) { console.error(err); }
                    }
                }
            }
        }
    }
};