const { AuditLogEvent } = require('discord.js');
module.exports = {
    name: 'roleCreate',
    async execute(role, client) {
        const { guild } = role;
        const fetchedLogs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.RoleCreate });
        const log = fetchedLogs.entries.first();
        if (!log || log.createdTimestamp < (Date.now() - 5000)) return;

        if (log.target.id === role.id) {
            const executorMember = await guild.members.fetch(log.executor.id).catch(() => null);
            const isSafe = await client.checkWhitelist(executorMember, guild.ownerId, 'roleCreate');

            if (!isSafe) {
                try {
                    await client.closeAllAdminPermissions(guild);
                    await role.delete('Guard: İzinsiz oluşturulan rol.');
                    
                    await client.sendLog(client, guild, 'rol', {
                        title: 'İzinsiz Rol Oluşturuldu!',
                        description: `**Açılan Rol:** \`${role.name}\`\n\n🔒 **Aksiyon:** Sunucu kilitlendi, yönetici yetkileri çekildi.\n🔄 **Durum:** Açılan rol anında silindi.`,
                        executor: log.executor
                    });
                } catch (err) { console.error(err); }
            }
        }
    },
};