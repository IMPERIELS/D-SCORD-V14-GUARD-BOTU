const { AuditLogEvent } = require('discord.js');
module.exports = {
    name: 'guildBanAdd',
    async execute(ban, client) {
        const { guild, user } = ban;
        const fetchedLogs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.MemberBanAdd });
        const log = fetchedLogs.entries.first();
        if (!log || log.createdTimestamp < (Date.now() - 5000)) return;

        if (log.target.id === user.id) {
            const executorMember = await guild.members.fetch(log.executor.id).catch(() => null);
            const isSafe = await client.checkWhitelist(executorMember, guild.ownerId, 'guildBanAdd');

            if (!isSafe) {
                try {
                    await client.closeAllAdminPermissions(guild);
                    await guild.bans.remove(user.id, 'Guard: İzinsiz ban açıldı.');
                    
                    await client.sendLog(client, guild, 'ban', {
                        title: 'İzinsiz Sağ Tık Ban!',
                        description: `**Banlanan Kişi:** <@${user.id}>\n\n🔒 **Aksiyon:** Sunucu kilitlendi, yönetici yetkileri çekildi.\n🔄 **Durum:** Ban atılan kullanıcının banı kaldırıldı.`,
                        executor: log.executor
                    });
                } catch (err) { console.error(err); }
            }
        }
    },
};