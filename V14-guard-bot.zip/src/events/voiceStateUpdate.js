const { AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'voiceStateUpdate',
    async execute(oldState, newState, client) {
        const { guild, member } = newState;
        if (!member) return;

        // Ne değiştiğini kontrol edelim
        const isMuted = !oldState.serverMute && newState.serverMute;
        const isDeafened = !oldState.serverDeaf && newState.serverDeaf;
        const isDisconnected = oldState.channelId && !newState.channelId;

        // Eğer bu üç tehlikeli işlemden biri yapılmadıysa (örneğin sadece sese gir/çık yaptıysa) iptal et
        if (!isMuted && !isDeafened && !isDisconnected) return;

        // Hangi logu arayacağımızı belirliyoruz
        const auditType = isDisconnected ? AuditLogEvent.MemberDisconnect : AuditLogEvent.MemberUpdate;
        
        // Logları çek
        const fetchedLogs = await guild.fetchAuditLogs({ limit: 1, type: auditType });
        const voiceLog = fetchedLogs.entries.first();
        
        // Log yoksa veya eskiyse (kullanıcı kendi çıkmış olabilir) iptal et
        if (!voiceLog || voiceLog.createdTimestamp < (Date.now() - 5000)) return;

        const { executor, target } = voiceLog;

        // Logdaki hedef ile sesi değişen kişi aynıysa
        if (target.id === member.id) {
            const executorMember = await guild.members.fetch(executor.id).catch(() => null);
            
            // Ses cezaları (mute, deafen, disconnect) için 'kick' kategorisi iznini kontrol ediyoruz
            const isSafe = await client.checkWhitelist(executorMember, guild.ownerId, 'voiceStateUpdate');

            if (!isSafe) {
                try {
                    // 1. Sunucuyu Kilitle (Tehlikeyi Durdur)
                    await client.closeAllAdminPermissions(guild);

                    // 2. İşlemi Geri Al (Restore - Eğer hala seste ise)
                    if (isMuted && newState.channelId) await newState.setMute(false, 'Guard Restore: İzinsiz susturma geri alındı.');
                    if (isDeafened && newState.channelId) await newState.setDeaf(false, 'Guard Restore: İzinsiz sağırlaştırma geri alındı.');

                    // 3. Eyleme göre log metni hazırla
                    let eylemMetni = '';
                    if (isMuted) eylemMetni = 'Sunucuda Susturuldu (Server Mute)';
                    else if (isDeafened) eylemMetni = 'Sunucuda Sağırlaştırıldı (Server Deafen)';
                    else if (isDisconnected) eylemMetni = 'Ses Kanalından Atıldı (Disconnect)';

                    // 4. Log Kanalına Bildir (Kick kanalına göndersin)
                    await client.sendLog(client, guild, 'kick', {
                        title: 'İzinsiz Ses Kanalı İşlemi!',
                        description: `**Mağdur:** <@${member.id}>\n**Yapılan Eylem:** ${eylemMetni}\n\n🔒 **Aksiyon:** Sunucu kilitlendi, yönetici yetkileri çekildi.\n🔄 **Durum:** Mümkünse kullanıcının mikrofon/kulaklık izni eski haline döndürüldü.`,
                        executor: executor,
                        color: 'Orange'
                    });

                } catch (err) {
                    console.error("voiceStateUpdate Hatası:", err);
                }
            }
        }
    },
};