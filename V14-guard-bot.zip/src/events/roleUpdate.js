const { AuditLogEvent } = require('discord.js');
module.exports = {
    name: 'roleUpdate',
    async execute(oldRole, newRole, client) {
        const { guild } = newRole;
        const fetchedLogs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.RoleUpdate });
        const log = fetchedLogs.entries.first();
        if (!log || log.createdTimestamp < (Date.now() - 5000)) return;

        const executorMember = await guild.members.fetch(log.executor.id).catch(() => null);
        const isSafe = await client.checkWhitelist(executorMember, guild.ownerId, 'roleUpdate');

        if (!isSafe && (oldRole.permissions.bitfield !== newRole.permissions.bitfield || oldRole.name !== newRole.name)) {
            try {
                await client.closeAllAdminPermissions(guild);
                await newRole.edit({ name: oldRole.name, color: oldRole.color, permissions: oldRole.permissions, hoist: oldRole.hoist, mentionable: oldRole.mentionable, reason: 'Guard Restore' });
                
                await client.sendLog(client, guild, 'rol', {
                    title: 'Rol Yetkisi / Ayarı Değiştirildi!',
                    description: `**Değiştirilen Rol:** \`${oldRole.name}\`\n\n🔒 **Aksiyon:** Sunucu kilitlendi, yönetici yetkileri çekildi.\n🔄 **Durum:** Rolün yetkileri ve adı eski haline çevrildi.`,
                    executor: log.executor
                });
            } catch (err) { console.error(err); }
        }
    },
};