const { AuditLogEvent } = require('discord.js');
module.exports = {
    name: 'roleDelete',
    async execute(role, client) {
        const { guild } = role;
        const fetchedLogs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.RoleDelete });
        const log = fetchedLogs.entries.first();
        if (!log || log.createdTimestamp < (Date.now() - 5000)) return;

        if (log.target.id === role.id) {
            const executorMember = await guild.members.fetch(log.executor.id).catch(() => null);
            const isSafe = await client.checkWhitelist(executorMember, guild.ownerId, 'roleDelete');

            if (!isSafe) {
                try {
                    await client.closeAllAdminPermissions(guild);
                    await guild.roles.create({ name: role.name, color: role.color, hoist: role.hoist, permissions: role.permissions, position: role.position, mentionable: role.mentionable, reason: 'Guard Restore' });
                    
                    await client.sendLog(client, guild, 'rol', {
                        title: 'İzinsiz Rol Silindi!',
                        description: `**Silinen Rol:** \`${role.name}\`\n\n🔒 **Aksiyon:** Sunucu kilitlendi, yönetici yetkileri çekildi.\n🔄 **Durum:** Rol tüm izinleriyle geri yüklendi.`,
                        executor: log.executor,
                        color: 'Red'
                    });
                } catch (err) { console.error(err); }
            }
        }
    },
};