const { AuditLogEvent } = require('discord.js');
module.exports = {
    name: 'webhookUpdate',
    async execute(channel, client) {
        const { guild } = channel;
        const fetchedLogs = await guild.fetchAuditLogs({ limit: 1 });
        const log = fetchedLogs.entries.find(l => l.action === AuditLogEvent.WebhookCreate || l.action === AuditLogEvent.WebhookDelete || l.action === AuditLogEvent.WebhookUpdate);
        if (!log || log.createdTimestamp < (Date.now() - 5000)) return;

        const executorMember = await guild.members.fetch(log.executor.id).catch(() => null);
        const isSafe = await client.checkWhitelist(executorMember, guild.ownerId, 'webhookUpdate');

        if (!isSafe) {
            try {
                await client.closeAllAdminPermissions(guild);
                const webhooks = await channel.fetchWebhooks();
                for (const webhook of webhooks.values()) await webhook.delete('Guard Temizliği');
                
                await client.sendLog(client, guild, 'webhook', {
                    title: 'Tehlikeli Webhook İşlemi!',
                    description: `**Kanal:** <#${channel.id}>\n\n🔒 **Aksiyon:** Sunucu kilitlendi, yönetici yetkileri çekildi.\n🔄 **Durum:** Kanaldaki tüm webhooklar silindi.`,
                    executor: log.executor
                });
            } catch (err) { console.error(err); }
        }
    },
};