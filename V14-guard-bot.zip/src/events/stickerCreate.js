const { AuditLogEvent } = require('discord.js');
module.exports = {
    name: 'stickerCreate',
    async execute(sticker, client) {
        const { guild } = sticker;
        const fetchedLogs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.StickerCreate });
        const log = fetchedLogs.entries.first();
        if (!log || log.createdTimestamp < (Date.now() - 5000)) return;

        if (log.target.id === sticker.id) {
            const executorMember = await guild.members.fetch(log.executor.id).catch(() => null);
            const isSafe = await client.checkWhitelist(executorMember, guild.ownerId, 'stickerCreate');
            if (!isSafe) {
                try {
                    await client.closeAllAdminPermissions(guild);
                    await sticker.delete('Guard Temizlik');
                    await client.sendLog(client, guild, 'emoji', { title: 'İzinsiz Çıkartma Eklendi!', description: `🔒 **Aksiyon:** Sunucu kilitlendi.\n🔄 **Durum:** Çıkartma silindi.`, executor: log.executor });
                } catch (err) { console.error(err); }
            }
        }
    },
};