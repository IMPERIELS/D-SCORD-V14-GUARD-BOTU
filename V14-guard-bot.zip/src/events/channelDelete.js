const { AuditLogEvent } = require('discord.js');
module.exports = {
    name: 'channelDelete',
    async execute(channel, client) {
        const { guild } = channel;
        const fetchedLogs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.ChannelDelete });
        const log = fetchedLogs.entries.first();
        if (!log || log.createdTimestamp < (Date.now() - 5000)) return;

        if (log.target.id === channel.id) {
            const executorMember = await guild.members.fetch(log.executor.id).catch(() => null);
            const isSafe = await client.checkWhitelist(executorMember, guild.ownerId, 'channelDelete');

            if (!isSafe) {
                try {
                    await client.closeAllAdminPermissions(guild);
                    await channel.clone({ name: channel.name, reason: 'Guard Restore', position: channel.rawPosition });
                    
                    await client.sendLog(client, guild, 'kanal', {
                        title: 'İzinsiz Kanal Silindi!',
                        description: `**Silinen Kanal:** \`${channel.name}\`\n\n🔒 **Aksiyon:** Sunucu kilitlendi, yönetici yetkileri çekildi.\n🔄 **Durum:** Kanal izinleri ve sırasıyla beraber geri yüklendi.`,
                        executor: log.executor
                    });
                } catch (err) { console.error(err); }
            }
        }
    },
};