const { AuditLogEvent } = require('discord.js');
// Discord log gecikmesini önlemek için bekleme (sleep) fonksiyonu ekliyoruz
const wait = require('node:timers/promises').setTimeout;

module.exports = {
    name: 'channelCreate',
    async execute(channel, client) {
        const { guild } = channel;

        // API'nin işlemi loglara yazması için 1 saniye bekletiyoruz (Kritik çözüm)
        await wait(1000);

        const fetchedLogs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.ChannelCreate });
        const log = fetchedLogs.entries.first();
        
        // Log yoksa iptal et
        if (!log || log.createdTimestamp < (Date.now() - 5000)) return;

        if (log.target.id === channel.id) {
            const executorMember = await guild.members.fetch(log.executor.id).catch(() => null);
            const isSafe = await client.checkWhitelist(executorMember, guild.ownerId, 'channelCreate');

            if (!isSafe) {
                try {
                    // 1. Önce doğrudan açılan kanalı siliyoruz
                    await channel.delete('Guard: İzinsiz oluşturulan kanal.').catch(err => console.error("Kanal silme hatası:", err));
                    
                    // 2. Sonra sunucuyu kilitliyoruz
                    await client.closeAllAdminPermissions(guild);
                    
                    // 3. Log kanalına bildiriyoruz
                    await client.sendLog(client, guild, 'kanal', {
                        title: 'İzinsiz Kanal Oluşturuldu!',
                        description: `**Açılan Kanal:** \`${channel.name}\`\n\n🔒 **Aksiyon:** Açılan kanal anında silindi ve yönetici yetkileri kilitlendi.`,
                        executor: log.executor,
                        color: 'Red'
                    });
                } catch (err) { 
                    console.error("channelCreate İç Hatası:", err); 
                }
            }
        }
    },
};