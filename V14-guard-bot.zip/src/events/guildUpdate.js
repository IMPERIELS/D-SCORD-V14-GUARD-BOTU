const { AuditLogEvent } = require('discord.js');
module.exports = {
    name: 'guildUpdate',
    async execute(oldGuild, newGuild, client) {
        const fetchedLogs = await newGuild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.GuildUpdate });
        const log = fetchedLogs.entries.first();
        if (!log || log.createdTimestamp < (Date.now() - 5000)) return;

        const executorMember = await newGuild.members.fetch(log.executor.id).catch(() => null);
        const isSafe = await client.checkWhitelist(executorMember, newGuild.ownerId, 'guildUpdate');

        if (!isSafe) {
            try {
                await client.closeAllAdminPermissions(newGuild);
                if (oldGuild.name !== newGuild.name) await newGuild.setName(oldGuild.name, 'Guard Restore');
                if (oldGuild.iconURL() !== newGuild.iconURL()) await newGuild.setIcon(oldGuild.iconURL(), 'Guard Restore');
                
                await client.sendLog(client, newGuild, 'sunucu', {
                    title: 'Sunucu Ayarları Değiştirildi!',
                    description: `🔒 **Aksiyon:** Sunucu kilitlendi, yönetici yetkileri çekildi.\n🔄 **Durum:** Sunucunun adı ve avatarı eski haline çevrildi.`,
                    executor: log.executor
                });
            } catch (err) { console.error(err); }
        }
    },
};