const { EmbedBuilder } = require('discord.js');
const db = require('croxydb');

module.exports = async (client, guild, category, data) => {
    // Veritabanından sunucuya ait log kanallarını çekiyoruz
    const logChannels = db.get(`logs_${guild.id}`);
    
    // Eğer loglar komutu kullanılmamışsa veya kategori yoksa iptal et
    if (!logChannels || !logChannels[category]) return;

    // Hedef kanalı bul
    const channel = guild.channels.cache.get(logChannels[category]);
    if (!channel) return;

    // Şık Embed Tasarımı
    const embed = new EmbedBuilder()
        .setTitle(`🛡️ ${data.title}`)
        .setDescription(data.description)
        .setColor(data.color || 'Red') // Varsayılan renk kırmızı
        .setTimestamp()
        .setFooter({ text: client.config.botIsmi, iconURL: guild.iconURL() });

    // Eğer işlemi yapan kişi (executor) belirtilmişse yazar kısmına ekle
    if (data.executor) {
        embed.setAuthor({ 
            name: `${data.executor.tag} (${data.executor.id})`, 
            iconURL: data.executor.displayAvatarURL({ dynamic: true }) 
        });
    }

    try {
        await channel.send({ embeds: [embed] });
    } catch (err) {
        console.error(`Log kanalına (${category}) mesaj gönderilemedi:`, err);
    }
};